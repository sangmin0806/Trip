package com.ssafy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ssafy11thProjectTripApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ssafy11thProjectTripApplication.class, args);
	}

}
